<?php

namespace CadpazBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CadpazBundle extends Bundle
{

}
