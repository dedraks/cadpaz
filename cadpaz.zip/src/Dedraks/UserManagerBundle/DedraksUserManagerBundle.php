<?php

namespace Dedraks\UserManagerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DedraksUserManagerBundle extends Bundle
{
}
