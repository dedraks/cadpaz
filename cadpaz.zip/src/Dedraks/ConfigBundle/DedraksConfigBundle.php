<?php

namespace Dedraks\ConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DedraksConfigBundle extends Bundle
{
}
