#!/bin/bash

apigen generate -d doc -s . --exclude vendor,web,bin,doc,nbproject,app/cache,app/logs,app/SymfonyRequirements.php,app/AppCache.php,app/AppKernel.php,app/check.php


