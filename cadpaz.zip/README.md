CadPaz - Projeto Casa da Paz
========================

Projeto criado utilizando o framework Symfony Standard Edition.

Qual o objetivo do projeto?
--------------

O projeto tem os seguintes objetivos:

  * Cadastrar os usuários atendidos na Casa da Paz;

  * Registrar todos os atendimentos feitos aos usuários;

  * Obter relatórios diversos dos atendimentos;
